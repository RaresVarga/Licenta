import React from 'react';
import { Link, Head } from '@inertiajs/react';
import '@/Components/Navbar/navbarrr.css';  
import SectiuniHome from '@/Components/Homepage/sectiuniHomepage/SectiuniHome';
import Navbar from '@/Components/Homepage/Navbar/Navbar';

export default function AdminDashboard() {
    return (
        <>
            
            
        </>
    );
}
